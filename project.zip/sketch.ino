#include <Wire.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <DHT.h>

#define ONE_WIRE_BUS 4
#define DHTPIN 15
#define DHTTYPE DHT22
#define SOIL_PIN 34
#define LIGHT_PIN 33

OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature soilTemp(&oneWire);
DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  soilTemp.begin();
  dht.begin();
}

void loop() {
  // Real-time sensors
  soilTemp.requestTemperatures();
  float soilTemperature = soilTemp.getTempCByIndex(0);
  float airTemp = dht.readTemperature();
  float humidity = dht.readHumidity();
  int soilRaw = analogRead(SOIL_PIN);
  float soilMoisture = map(soilRaw, 0, 4095, 0, 100);
  int lightRaw = analogRead(LIGHT_PIN);
  float lux = map(lightRaw, 0, 4095, 0, 1000);

  // Simulated features for AI
  float ph = 6.8;            // simulate pH
  float N = 30, P = 20, K = 15;  // simulate nutrients
  float rainfall = 5;        // simulate rainfall in mm

  // JSON output
  Serial.print("{\"soilTemp\":"); Serial.print(soilTemperature);
  Serial.print(",\"airTemp\":"); Serial.print(airTemp);
  Serial.print(",\"humidity\":"); Serial.print(humidity);
  Serial.print(",\"soilMoisture\":"); Serial.print(soilMoisture);
  Serial.print(",\"lux\":"); Serial.print(lux);
  Serial.print(",\"ph\":"); Serial.print(ph);
  Serial.print(",\"N\":"); Serial.print(N);
  Serial.print(",\"P\":"); Serial.print(P);
  Serial.print(",\"K\":"); Serial.print(K);
  Serial.print(",\"rainfall\":"); Serial.print(rainfall);
  Serial.println("}");
  
  delay(5000);
}
